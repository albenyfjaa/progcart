import os
from qgis.core import QgsVectorLayer, QgsProject, QgsRasterLayer, QgsWkbTypes, QgsCoordinateReferenceSystem
import processing

class AddLayer:
    def __init__(self, destination_folder, layer_extent):
        self.layer_extent = layer_extent
        self.destination_folder = destination_folder
        
        # Add Sirgas Stations Layer
        layer = os.path.join(self.destination_folder, "estacoes_sirgas.shp")
        layer_obj = QgsVectorLayer(layer, os.path.basename(layer)[:-4], "ogr") # Creates a QgsVectorLayer object for vector layers
        # layer_obj.setCrs(QgsCoordinateReferenceSystem("EPSG:9378"))
        QgsProject.instance().addMapLayer(layer_obj)
        print("Layer adicionada ao mapa: ", layer)

        # Add Layer Extent
        
        if self.layer_extent:
            layer_extent_obj = QgsVectorLayer(self.layer_extent, os.path.basename(self.layer_extent)[:-4], "ogr")
            if layer_extent_obj.isValid():
                geometry_type = QgsWkbTypes.geometryType(layer_extent_obj.wkbType())
                if geometry_type == QgsWkbTypes.PolygonGeometry:
                    QgsProject.instance().addMapLayer(layer_extent_obj)
                    print("Layer de extensão adicionada ao mapa:", self.layer_extent)

                    # Perform clip operation
                    clipped_output = os.path.join(self.destination_folder, "estacoes_sirgas_clip.shp")
                    processing.run("native:clip", {
                        'INPUT': layer_obj,
                        'OVERLAY': layer_extent_obj,
                        'OUTPUT': clipped_output
                    })

                    clipped_layer = QgsVectorLayer(clipped_output, "estacoes_sirgas_clip", "ogr")
                    if clipped_layer.isValid():
                        QgsProject.instance().addMapLayer(clipped_layer)
                        print("Layer clipado adicionado ao mapa:", clipped_output)
                    else:
                        print("Falha ao carregar camada clipada.")
                else:
                    print("Camada de extensão ignorada: não é do tipo polígono.")
            else:
                print("Falha ao carregar camada de extensão:", self.layer_extent)
        else:
                print("Nenhuma camada de extensão fornecida.")







""" import os
from qgis.core import (
    QgsVectorLayer, QgsProject, QgsCoordinateReferenceSystem
)
import processing

class AddLayer:
    def __init__(self, destination_folder, layer_extent):
        self.layer_extent = layer_extent
        self.destination_folder = destination_folder

        # Original layer (geocentric)
        original_layer_path = os.path.join(self.destination_folder, "estacoes_sirgas.shp")
        original_layer = QgsVectorLayer(original_layer_path, "estacoes_sirgas", "ogr")

        # Define original CRS (EPSG:9378)
        original_layer.setCrs(QgsCoordinateReferenceSystem("EPSG:9378"))

        # Reproject to EPSG:4674 (SIRGAS 2000 - 2D)
        output_path = os.path.join(self.destination_folder, "estacoes_sirgas_reprojected.shp")
        processing.run("native:reprojectlayer", {
            'INPUT': original_layer,
            'TARGET_CRS': QgsCoordinateReferenceSystem("EPSG:4674"),
            'OUTPUT': output_path
        })

        # Load the reprojected layer
        reprojected_layer = QgsVectorLayer(output_path, "estacoes_sirgas_reprojected", "ogr")
        QgsProject.instance().addMapLayer(reprojected_layer)
        print("Layer reprojetada adicionada ao mapa:", output_path)

        # Add extent layer (if needed)
        extent_layer = QgsVectorLayer(self.layer_extent, os.path.basename(self.layer_extent)[:-4], "ogr")
        QgsProject.instance().addMapLayer(extent_layer)
        print("Layer adicionada ao mapa:", self.layer_extent) """





""" import os
from qgis.core import QgsVectorLayer, QgsProject, QgsRasterLayer, QgsWkbTypes

class AddLayer:
    def __init__(self, destination_folder):
        self.destination_folder = destination_folder
        layer = os.path.join(self.destination_folder, "estacoes_sirgas.shp")
        layer_obj = QgsVectorLayer(layer, os.path.basename(layer)[:-4], "ogr") # Creates a QgsVectorLayer object for vector layers
        QgsProject.instance().addMapLayer(layer_obj)
        print("Layer adicionada ao mapa: ", layer)

AddLayer("C:\\Users\\filip\\progcart\\projeto_2_geopandas\\docs\\files\\download_teste") """