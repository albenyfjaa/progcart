import os
from qgis.core import QgsVectorLayer, QgsProject, QgsRasterLayer, QgsWkbTypes

class AddLayer:
    def __init__(self, destination_folder, layer_extent):
        self.layer_extent = layer_extent
        self.destination_folder = destination_folder
        
        # Add Sirgas Stations Layer
        layer = os.path.join(self.destination_folder, "estacoes_sirgas.shp")
        layer_obj = QgsVectorLayer(layer, os.path.basename(layer)[:-4], "ogr") # Creates a QgsVectorLayer object for vector layers
        QgsProject.instance().addMapLayer(layer_obj)
        print("Layer adicionada ao mapa: ", layer)

        # Add Layer Extent
        layer_extent_obj = QgsVectorLayer(self.layer_extent, os.path.basename(self.layer_extent)[:-4], "ogr") # Creates a QgsVectorLayer object for vector layers
        QgsProject.instance().addMapLayer(layer_extent_obj)
        print("Layer adicionada ao mapa: ", self.layer_extent)


""" import os
from qgis.core import QgsVectorLayer, QgsProject, QgsRasterLayer, QgsWkbTypes

class AddLayer:
    def __init__(self, destination_folder):
        self.destination_folder = destination_folder
        layer = os.path.join(self.destination_folder, "estacoes_sirgas.shp")
        layer_obj = QgsVectorLayer(layer, os.path.basename(layer)[:-4], "ogr") # Creates a QgsVectorLayer object for vector layers
        QgsProject.instance().addMapLayer(layer_obj)
        print("Layer adicionada ao mapa: ", layer)

AddLayer("C:\\Users\\filip\\progcart\\projeto_2_geopandas\\docs\\files\\download_teste") """